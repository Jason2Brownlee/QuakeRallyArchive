===============================
Checkered Flag - Gold Cup Beta
===============================
Use 'b' to add a bot.
Use 'o' for observer mode.
Use 'F9' to change your vehicle model.

More on the way!!!