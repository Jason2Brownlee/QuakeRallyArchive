----------------------------------
Checkered Flag-Gold Cup Beta Demo
----------------------------------

Title    : Gold Cup Demo
Filename : GCdemo.zip
Version  : Beta Demo
Date     : 12-24-99
Author   : Halo 9, Chazz
Email    : JKlint2569@aol.com (Halo 9) 
Credit   : Id Software, The Impact Team, Our brains.


--------------
Type of QC Mod
--------------
Bot             : No (coming soon!)
Compilation     : No (coming soon!)
Deathmatch      : No (coming soon!)
Teamplay        : No
Monster         : No
skin            : Yes (the car)
Sound           : Yes (car sounds)
Weapon          : No (coming soon!)
Utilities       : No
Other           : Physics Demo


----------------
Format of QuakeC
----------------
unified diff  : No
context diff  : No
.qc files     : No
progs.dat     : No (coming soon!)

----------------
Construction
----------------

Base                  : Quake/Qrally (sounds & menu)
Build Time            : 1 1/2 weeks
Editor(s) used        : WorldCraft, DosEdit, Truespace, Proqcc, Notepad, etc.
Known Bugs            : Level included has not been vised. Gray stuff..
Impulses              : None


-------------------------------
Description of the Modification
-------------------------------

 This is a demo. It is not a playable demo. It is merely the graphics, a 
level, and the physics code being displayed through a demo. This is not the 
actual mod, this is to show off the physics code of GoldCup. There is no 
progs.dat so you can't play it or attempt to decompile it. The closest you 
can get to playing it is watching the demo.. The text is hard to see against
the level in software.

 The level included is a demo level. It is provided as is, unvised. Mainly
a testing level. The level is being redesigned right now to look better and
go faster...

-------------------------------
How to Install the Modification
-------------------------------

 Unzip contents of the zip into a directory under your Quake directory. You 
should know how to do this.. I recommend 'GCdemo' to keep everything 
organized. Then in a dos prompt, under your Quake directory, type either:

quake -game gcdemo

    or if you have opengl Quake

glquake -game gcdemo


 GLQuake will go slow since the map hasn't been vised and is pretty big.
I recommend software in a high resoulution..


-----------------
Technical Details
-----------------

Halo 9:
	All maps were constructed with Worldcraft 1.6. Textures were drawn 
from the following sources:

-Original Quake Texures
-Hexen II converted to Quake Palette (from Frib)
-Portal of Praveus converted to Quake Palette
-CTF Textures
-QRally Textures

Curves were made by 24-sided cylinders, hollowed out with the horizontal 
surfaces cut out. This makes for 8 angles between degrees of 0 and 90. 
Carving was used sparingly, and with much regret. Carving is evil. Do not 
carve.




Chazz:

 The car was modeled in Truespace SE 1.0, the first version of truespace. 
Then I exported it to an ascii file and converted it into an mdl with 
meddle. After that I used Neopaint v3.0 to draw a stupid texture.. Then I 
edited the model with StudioMDx and QmeLite. Also did some texture editing 
in QmeLite. 

 The code was written without outside help although I asked for it but never 
got it. If you look closely, the car doesn't angle itself to slopes yet. The
tilting is caused by the car turning. The top of the car tilts outward from 
the turn. Gives it a more realistic look. The car also slides a bit on the 
ground as to give the effect of uhh, sliding.. It doesn't slide much but it 
does allow for easy-to-do 180 turns and stuff. If you have questions then 
mail me (see below)..


------------------
Author Information
------------------
	
	Joshua 'Halo 9' Klint:-----------Mapper, Game Concept.
email=JKlint2569@aol.com

 Joshua is a pre-med student at California State University, Fresno. He is a 
junior, and maintains a 3.75 science GPA. He has applied to transfer to the 
University of California at Berkeley, Davis, and Santa Barbara for Fall of 
2000, and has already been accepted to UCSB. He has been mapping Quake for 
about a year now, and owes his geometric genius to the Legos he has 
collected over the course of his life. 


	Charlie 'Chazz' Van Noland:------Programmer, modeler.
email=chazzmatazz@hotmail.com

 Started programming at age 7 in qbasic. Over time developed a knack for 3d
arts (clay, modeling) and 3d perceptual thinking. Where he gets his 
ability to model crappy cars in 15 min. Spends time programming, loitering
on messageboards, hassling people, eating food, etc. Spent 2/3 of spare time
in his life to computers.. Maintains 3.5 in middle school (only 13!). Plans
on becoming a game developer/programmer later in life. 



--------------------------------------
Copyright and Distribution Permissions
--------------------------------------
 
 Do what you want except redistributing the zip after it's contents have been
modified. Just make sure that if you distribute it, you distribute the original
copy you got and not one you edited and stuff. Ok, wanna know what I am 
going to do? Watch....

The content and design of 'Checkered Flag-GoldCup' are Copyrighted by 
Team Impact and the Gold-Cup team. All rights reserved.

 There, now you can't steal our logos and stuff. Well you are capable of it
but it's supposed to be against the constitution or something like that. Oh
last but not least, have fun.. :?)

(Readme written by Charlie 'Chazz' Van Noland)