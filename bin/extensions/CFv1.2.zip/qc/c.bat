cd..
cd..
quake -game racer +deathmatch 1 +map map1

