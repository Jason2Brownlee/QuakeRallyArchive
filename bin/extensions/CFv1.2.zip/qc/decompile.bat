c:
cd\windows\desktop\programfiles\quakec~1\proqc
proqcc -dec
