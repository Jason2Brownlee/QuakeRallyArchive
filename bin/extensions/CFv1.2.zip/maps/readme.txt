Checkered Flag - Gold Cup
=========================
Lucid Designs, Inc.

Demo map by halo 9
jklint2569@aol.com

*Put this map in your quake/id1/maps directory.
Type the following command into the Quake console:
"map map1"

Check out these sites:
------------------------
http://www.planetquake.com/goldcup
http://www.geocities.com/lucid_omen