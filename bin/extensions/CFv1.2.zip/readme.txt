---------------------------------
Checkered Flag-Gold Cup Beta v1.2
---------------------------------
Title    : Gold Cup Beta
Filename : GCBv11.zip
Version  : Beta Demo
Date     : Started 12-22-99, Released 1-23-00
Author   : Lucid Designs
Email    : halo9@planetquake.com, koolio@mdqnet.net
Credit   : Id Software, Jeff "Stecki" Garstecki

-------------------------------
IMPORTANT! - How to Install the Modification
-------------------------------

1.  Unzip contents of the zip into a directory under your Quake directory. You 
    should know how to do this.. I recommend 'GC' to keep everything 
    organized. 

2.  Place all tga files in the following directory:
	
    	c:/quake/id1/env

3.  Go to "start", then "run", and add this line:

    	c:/quake/lucidgl.exe -game gc +map gc01 +r_mirroralpha 0.9 +r_shadows 1 +r_waterwarp 0

    Or if you are playing in software only:

    	c:/quake/quake.exe -game gc +map gc01

WILL NOT RUN IN WINQUAKE



--------------
Type of QC Mod
--------------
Bot             : In development
Compilation     : Yes
Deathmatch      : Yes
Teamplay        : Nope
Monster         : Nope
Skins/Models    : Yes 
Sound           : Yes
Weapon          : In development
Utilities       : No
Other           : No


----------------
Format of QuakeC
----------------
unified diff  : No
context diff  : No
.qc files     : Yes
progs.dat     : Yes

----------------
Construction
----------------
Base                  : Quake
Build Time            : 8 weeks
Editors Used	      : See below		
Impulses              : H = Toggle headlights.
			F9 = Change vehicle.
			uparrow = accelerate
			downarrow = reverse
			
-------------------------------
Description of the Modification
-------------------------------

In short, Checkered Flag is Quake Rally with:

	-Better Physics
	-way better maps
	-More cars
	-Better Graphics
	-Bots!  (NOT INCLUDED IN THIS VERSION!)


How does Checkered Flag pick up where Qrally stopped?:

	1.) The physics are being coded with realism, fun, and qrally's original physics in mind.. The cars handle way
more realistically while keeping the playing style much the same as Qrally. The cars in Qrally were really 'slippery' and
when you took a turn, the car would turn all over the place but wouldn't really move around alot like it was 'sliding'...
Play it and you'll see what I mean.

	2.) With a breakthrough in Quake mapping halo 9 invented, we have tracks with smooth, curved hills 
and roads. The maps in Quake Rally had to many 90-degree turns and were very 'square'.. If you have played Quake Rally then
you have a good understanding..

	3.) Ever notice how the cars in qrally are all used twice? They just changed the skin? No, that's not right.. We have
way more cars and none of them are using the same model with just a different skin.. You will be happy with the selection
you have of 'real' cars....

	4.) Graphics are way better since we are using specialized level vising and lighting tools to create more realistic
shadows in the maps. The models have a higher end polygon count so they are more detailed.. What's that you say? Models 
shouldn't have lotsa polygons?! Yeah, if you still have a 486! Most computers today (about 95%) are capable of handling the
polys in GoldCup. Especially if you are running GlQuake.. If you can easily get a 50 FPS with 'timedemo demo2' in GlQuake
then you will enjoy the fact that we included extra polygons in our levels.


BOTS NOT INCLUDED IN THIS VERSION
	5.) Bots, hmmmnn, that's a hard one! Actually, the bots really follow a predefined set of waypoints. No, the bots
don't follow them like platforms do.. They follow them with physics.. Here is a list of why:

 	-Bots don't have to touch a waypoint, they just gotta get near it. 
	-Bots can be bumped around by other bots.
	-The bots skid and can't turn sharply.

As you can see, the bots have all the turning, accleration, and traction limitations as the player does. We aren't cheap.



There are still bugs but it's still really fun to play! Especially with all the included models to play with. I touched up
the skins a bit and some of the code before this release. I bet that after you play this version, you won't be able to wait
for the full release with the bots in it! 

There are only 6 cars right now. That's just because it's a beta.. The finished version is meant to include 8-12 models.
One of which I am sure is a jeep. hehe.. Anyhow, keep your eye on the GoldCup page (www.planetquake.com/goldcup/)...

----------
Known Bugs
----------

	I am going to just list these out...


-Car is damaged when driving and looking straight up.
-If near a wall, zoom out w/chasecam and camera moves near car.  
This will be fixed with the camera views
-Steering behavior is affected by framerate. (not very noticable)

------------
Editors Used
------------

Tool Name	Desciption			Site
---------	----------------------------	--------------------------------------------------------------------
WorldCraft 1.6  A really good level/map 	N/A
		editing tool. Halo 9 used
		it.				

DosEdit		Used it to write 98% of the 	N/A (Comes with MS-DOS)
		GoldCup code.			

Truespace	A 3d modeling program I used
		to make logos and models.	http://www.calagari.com/

Proqcc		A QuakeC compiler. Simple
		and easy to use, I like it.     http://www.inside3d.com/download.shtml

Notepad		Windows				N/A (Comes with Win9x)

QmeLite		A mdl model editor. A demo      http://www.xs4all.nl/~renep/quakeme/
		version which only allows
		saving of models with 20
		or less frames.			

QuakeMe		The program that started        http://www.xs4all.nl/~renep/quakeme/
		Qme and Qmelite. From the
		same makers.

StudioMdx	This is a model editing 	http://www-kbs.ai.uiuc.edu/d-kruse/studioMDx/news.htm
		utility I found while 
		surfing the web. It's
		not finished and has some
		bugs but is cool, sorta.


PhotoShop 5.0   You should have heard of	http://www.adobe.com/ (the makers of PhotoShop) 
		this before. It's a 
		powerful graphics editing
		tool.			

NeoPaint	A pretty cool graphics		http://www.neosoftware.com/ (from the makers of
		editing tool. I use it 						quikmenu!)
		to do stuff in the
		Quake pallete. It's
		easy to use!


AdQuedit	A really good Quake		http://www.planetquake.com/chopshop/editing/quake/
		editing tool. Lets you           (Not adquedit based but they use it alot!)
		extract textures, sprites
		skins, pak files, etc.


Endoomer	An 'end screen' editing		http://www.planetquake.com/chopshop/editing/quake/
		tool. You know, the red
		screen that comes up when
		you exit Quake.	


Winpack		I used this to make the		N/A (you can get it from ftp.cdrom.com)
		pak file. It's a pak 
		editor.		


Meddle		This is the original		N/A for the original version. New version is lame.
		Dos version. I use it
		to convert ascii to mdl.	

PaintShop	Excellent and hella fun. 
Pro 6	

TexMex		Textures utility

Trylite		Excellent light program

Treebsp		Map compiler

-----------------
Technical Details
-----------------

halo 9:

All maps were constructed with Worldcraft 1.6. Textures were drawn 
from the following sources:

-Original Quake Texures
-Hexen II converted to Quake Palette (from Frib)
-Portal of Praveus converted to Quake Palette
-QRally Textures
-Originals by halo 9 and Chazz

A wad file and set of prefabs will be released with the final version.


Chazz:

The car was modeled in Truespace SE 1.0, the first version of truespace. 
Then I exported it to an ascii file and converted it into an mdl with 
meddle. After that I used Neopaint v3.0 to draw a stupid texture.. Then I 
edited the model with StudioMDx and QmeLite. Also did some texture editing 
in QmeLite. 

The code was written without outside help although I asked for it but never 
got it. If you look closely, the car doesn't angle itself to slopes yet. The
tilting is caused by the car turning. The top of the car tilts outward from 
the turn. Gives it a more realistic look. The car also slides a bit on the 
ground as to give the effect of uhh, sliding.. It doesn't slide much but it 
does allow for easy-to-do 180 turns and stuff. If you have questions then 
mail me (see below)..

------------------
Author Information
------------------

	'Lucid Designs' was started in December of '99. Although we didn't
have a name, we were still 'Lucid Designs'. It all started on the old 
I3d messageboard (www.inside3d.com). Chazz had given up entirely on Quake 
editing but hung out at the I3d messageboard to help budding programmers 
with their mods. Halo 9 told everyone about his quitting programming and 
just sticking with mapping. 

	He started to develop a mapping technique for making
Qrally maps. He postponed his last project 'Darkness-Awaits' for a qrally 
extension. He called it 'Qrally-Checkered Flag'. Chazz replied with a 
message saying he could do allthe coding and stuff since he had nothing 
better to do, only later did he find out that it'd be alot longer before 
the project would be finished. 

	Chazz sucks his ass off on the physics to get them working.
halo continued to explore the possibilities with his new segmented
tracking technique. Halo 9 later decided to change the name...
It was called 'Checkered Flag-GoldCup'. Chazz had a site up at
http://members.gotnet.net/chaz/ and had emailed planetquake about
the newest mod in development. 

	Within 30 minutes, PlanetQuake had
made the post on PQ and had offered to host the GoldCup site, this
was the beginning of something big. That same day, GoldCup was
all ready to go and was uploaded to PlanetQuake. The old site
now redirected people to the PlanetQuake site. It was cool....

	Soon enough, a beta demo came out. It wasn't a playable beta, 
just a demo to watch. People loved it. It was the first release of
GoldCup. In 2 weeks, Lucid Designs had accomplished 1/2 of an
equivalent to Qrally. Qrally took 8 months to get it to where it is
now. Nothing could stop us..................


	A few people offered to re-design the site for us.
Thomas 'Rebel Angel' Sturm was the lucky man who had made up a site
design at www.doomworld.com/deskdoom/gc/ (not there any longer).
we gave him the OK and he finished it off and sent us the zip..
We got the new site all uploaded and everything. We were getting 
bigger and better.....
 
	
	A few weeks later, another release was uhhhhhhhhhh, ummmnnn, 
released. But this one was playable. It included 3 car models and was 
very primitive. It came with all the code. It was the first playable 
beta of GoldCup. People sent in comments and stuff from all over the place. 
All of those comments helped make GoldCup's physics, graphics, maps and all
50% better. 

	Our goal is to always reach the finish line. Not with just speed
but with quality.	
	

We recommend you visit our website at: http://www.planetquake.com/goldcup/ and
check for news updates and version updates. We update almost everyday. There is
alot of info on there.

THEN CHAZZ QUIT.  Koolio took over in his place.


--------------------
Info On the Authors:
--------------------

	Joshua 'Halo 9' Klint
email=halo9@planetquake.com

 Joshua is a pre-med student at California State University, Fresno. He is a 
junior, and maintains a 3.75 science GPA. He has applied to transfer to the 
University of California at Berkeley, Davis, and Santa Barbara for Fall of 
2000, and has already been accepted to UCSB. He has been mapping Quake for 
about a year now, and owes his geometric genius to the Legos he has 
collected over the course of his life. 


	Charlie 'Chazz' Van Noland
email=chazzmatazz@hotmail.com

 Started programming at age 7 in qbasic. Over time developed a knack for 3d
arts (clay, modeling) and 3d perceptual thinking.  Where he gets his 
ability to model crappy cars in 15 min. As he experimented with
Qbasic, he became a more logic thinker. Spends time programming, loitering
on messageboards, hassling people, eating, etc. Spends 9/10 of spare time
in his life to computers.. Keeps 3.5 GPA in middle school (only 13!). Plans
on becoming a game developer/programmer later in life.



-------
Credits
-------
-Game Concept and Designer-

	Joshua 'halo 9' Klint

-Programming/GL-

	"Koolio"
	Charlie 'Chazz' Van Noland
	
-Mapping-
	
	Joshua 'halo 9' Klint

-Modeling and Skinning-

	Jeff 'Stecki' Garstecki

-Web Page Design-

	Thomas 'Rebel Angel' Sturm

-Special Thanks to-

	Pappy-R and Hellchick at Planetquake
	Ryan 'Ridha' Feltrin and the Impact Team

--------------------------------------
Copyright and Distribution Permissions
--------------------------------------

THE CONTENT AND DESIGN OF BOTH THE MOD 'Checkered Flag-GoldCup' AND
THE GoldCup WEBPAGE (www.planetquake.com/goldcup/) ARE COPYRIGHTED
BY Team Impact AND Lucid Designs. ALL RIGHTS RESERVED.