---------------------------------
Checkered Flag - GoldCup beta v1.3
---------------------------------
Title    : Checkered Flag - Gold Cup
Filename : Checkered Flag v1.3.zip
Version  : Beta Release v1.3
Date     : Started 12-22-99, Released 3-15-00
Author   : Lucid Designs
Email    : koolio@mdqnet.net, halo9@planetquake.com, tsturm@doomworld.com
Homepage : http://www.planetquake.com/lucid/goldcup

-------------------------------
IMPORTANT! - How to Install the Modification
-------------------------------

1.  Unzip contents of the zip into c:/quake/goldcup.  You must unzip the contents into this directory.

2.  Click on "Install Checkered Flag v1.3" to install the game.

3.  Click on the "Checkered Flag v1.3" shortcut to run the game. 
----------
Known Bugs
----------

-Car is damaged when driving and looking straight up.
-If near a wall, zoom out w/chasecam and camera moves near car.  
-Steering behavior is affected by framerate. (not very noticable)
-Car is lower than it should be upon starting.  Hitting F9 fixes the level of the vehicle model.
-Car sometimes angles down when it approaches a wall.
-Car goes into a wall and receives multiple collisions.  A "bounce" function would solve this.
-Car jumps around on the screen quite a bit
-Acceleration cause car to move further away from the camera
-Car occasionally kicks into reverse for no reason.
-Sometimes the car accelerates much too quickly in reverse.
-headlights are ridiculously bright.

--------------
Type of QC Mod
--------------
Bot             : In development
Compilation     : Yes
Deathmatch      : Yes
Teamplay        : Nope
Monster         : Nope
Skins/Models    : Yes 
Sound           : Yes
Weapon          : Yes
Utilities       : No
Other           : No

----------------
Format of QuakeC
----------------
unified diff  : No
context diff  : No
.qc files     : Yes
progs.dat     : Yes

----------------
Construction
----------------
Base                  : Quake
Build Time            : 12 weeks
Editors Used	      : See below		
Impulses              : H = Toggle headlights.
			F9 = Change vehicle.
			uparrow = accelerate
			downarrow = reverse
			
------------
Editors Used
------------

-DosEdit	-Endoomer	-Truespace	
-Proqcc		-Notepad	-QmeLite		
-QuakeMe	-StudioMdx	-PhotoShop 5.0  
-NeoPaint	-WorldCraft 1.6 -AdQuedit	
-Meddle		-Paint		-PaintShop Pro 6	
-Pak Explorer	-TexMex		-Quake Arnmy Knife
-Trylite	-Treebsp	-Winpack		

-------
Credits
-------

-GL Programming-
	Robert 'Koolio' de Hues
	
-QC Programming-
	Charlie 'Chazz' Van Noland

-Maps & Textures-
	Joshua 'halo 9' Klint	

-Web Page Design and Windows Interface-
	Thomas 'Rebel Angel' Sturm

-Models and Skins-
	Jeff 'Stecki' Garstecki

-Special Thanks to-
	Pappy-R and Hellchick of Planetquake
	Ryan 'Ridha' Feltrin and the Impact Team
	
--------------------------------------
Copyright and Distribution Permissions
--------------------------------------
THE CONTENT AND DESIGN OF BOTH THE MOD 'Checkered Flag - GoldCup' AND
THE GoldCup WEBPAGE (www.planetquake.com/lucid/goldcup) ARE COPYRIGHTED
BY Team Impact AND Lucid Designs(C) 1999-2000.  ALL RIGHTS RESERVED.