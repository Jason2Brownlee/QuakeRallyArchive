---------------------------------
Checkered Flag-Gold Cup Beta v1.1
---------------------------------
Title    : Gold Cup Demo
Filename : GCBv11.zip
Version  : Beta Demo
Date     : Started 12-22-99, Released 1-23-00
Author   : Lucid Designs
Email    : JKlint2569@aol.com (Halo 9), chazzmatazz@hotmail.com (Chazz)
Credit   : Id Software, The Impact Team, Our brains.....


--------------
Type of QC Mod
--------------
Bot             : Nope (In development)
Compilation     : Yes
Deathmatch      : Yes (not finished but it works!)
Teamplay        : Nope
Monster         : Nope
Skins/Models    : Yes (Good ones too!)
Sound           : Yes
Weapon          : Nope (In development)
Utilities       : Yes (It helps people have fun)
Other           : Nope


----------------
Format of QuakeC
----------------
unified diff  : No
context diff  : No
.qc files     : Yes
progs.dat     : Yes

----------------
Construction
----------------
Base                  : Quake/Qrally (sounds & menu only since it's meant to be a form of qrally!)
Build Time            : 3 weeks
Editors Used	      : See below (we dedicated a section of this txt file to it!)			
Impulses              : S = Move camera in.
			X = Move camera out.
			H = Toggle headlights.
			F9 = Change vehicle.


-------------------------------
Description of the Modification
-------------------------------

 (This is a solid basis for GoldCup, mainly a physics test and bug test. Feel free to send
us your comments. Remember, this isn't the full release, just a beta. The racing code isn't
finished either.. Alot still needs to be done, IMO....Anyways, have fun!)

 Ever played Quake Rally? Well guess what, that's what this is! Wait! Don't go! It's not exactly Qrally. It's a 'better' 
Qrally. In short, GoldCup is Quake Rally with:

	-Better Physics
	-way better maps
	-More cars
	-Better Graphics
	-Bots!  (NOT INCLUDED IN THIS VERSION!)


Why is GoldCup so much better than Qrally?:

	1.) The physics are being coded with realism, fun, and qrally's original physics in mind.. The cars handle way
more realistically while keeping the playing style much the same as Qrally. The cars in Qrally were really 'slippery' and
when you took a turn, the car would turn all over the place but wouldn't really move around alot like it was 'sliding'...
Play it and you'll see what I mean.

	2.) With a breakthrough in Quake mapping Halo 9 (to be refered to as halo) invented, we have tracks with smooth, curved hills 
and roads. The maps in Quake Rally had to many 90-degree turns and were very 'square'.. If you have played Quake Rally then
you have a good understanding..

	3.) Ever notice how the cars in qrally are all used twice? They just changed the skin? No, that's not right.. We have
way more cars and none of them are using the same model with just a different skin.. You will be happy with the selection
you have of 'real' cars....

	4.) Graphics are way better since we are using specialized level vising and lighting tools to create more realistic
shadows in the maps. The models have a higher end polygon count so they are more detailed.. What's that you say? Models 
shouldn't have lotsa polygons?! Yeah, if you still have a 486! Most computers today (about 95%) are capable of handling the
polys in GoldCup. Especially if you are running GlQuake.. If you can easily get a 50 FPS with 'timedemo demo2' in GlQuake
then you will enjoy the fact that we included extra polygons in our levels.


	   (BOTS NOT INCLUDED IN THIS VERSION)
	5.) Bots, hmmmnn, that's a hard one! Actually, the bots really follow a predefined set of waypoints. No, the bots
don't follow them like platforms do.. They follow them with physics.. Here is a list of why:

 	-Bots don't have to touch a waypoint, they just gotta get near it. 
	-Bots can be bumped around by other bots.
	-The bots skid and can't turn sharply.

As you can see, the bots have all the turning, accleration, and traction limitations as the player does. We aren't cheap.



There are still bugs but it's still really fun to play! Especially with all the included models to play with. I touched up
the skins a bit and some of the code before this release. I bet that after you play this version, you won't be able to wait
for the full release with the bots in it! Well you better wait, this is a hard project. I can't believe we got this far
in a month!

There are only 6 cars right now. That's just because it's a beta.. The finished version is meant to include 8-12 models.
One of which I am sure is a jeep. hehe.. Anyhow, keep your eye on the GoldCup page (www.planetquake.com/goldcup/)...


-------------------------------
How to Install the Modification
-------------------------------

 Unzip contents of the zip into a directory under your Quake directory. You 
should know how to do this.. I recommend 'GCdemo' to keep everything 
organized. Then in a dos prompt, under your Quake directory, type either:

quake -game gcdemo

    or if you have opengl Quake

glquake -game gcdemo


 Runs very well in both versions of Quake. GoldCup does NOT run in Winquake since we didn't have compatibility in mind. Most
people use either Quake or GlQuake anyhow so we figured it didn't really matter. If you like Winquake, then you are into
software.. Just use Dos quake! Or, if you have a 3D-card or accelerator then use GlQuake... Have fun!

 There are only 2 maps included, 'map1' and 'test'.. There will soon be a 'map2' released as a separete map on the GoldCup
page. There will also be a 'start' map sometime soon. Keep your eyes peeled!...


----------
Known Bugs
----------

	I am going to just list these out...

-Car is damaged when driving and looking straight up.
-Car doesn't start at same angle as 'player_info_start'.
-Car speed has tremendous slowdown when going up some hills (QBSP error).
-If near a wall, zoom out w/chasecam and camera moves near car.
-Steering behavior is affected by framerate. (not very noticable)
-Does NOT run in WinQuake (not known why).
-Sometimes, when the car hits a wall, it angles downward (we think it's a QBSP error)
-If you pass close to a wall without touching it, the 'hitwall' function is still called.
-Corvette angles downward when going up hills unless you cycle through cars first.
-Turn off mlook and you can strafe!
-Ummm, uhh, send em in!


------------
Editors Used
------------

Tool Name	Desciption			Site
---------	----------------------------	--------------------------------------------------------------------
WorldCraft      A really good level/map 	N/A
		editing tool. Halo 9 used
		it.				

DosEdit		Used it to write 98% of the 	N/A (Comes with MS-DOS)
		GoldCup code.			

Truespace	A 3d modeling program I used
		to make logos and models.	http://www.calagari.com/

Proqcc		A QuakeC compiler. Simple
		and easy to use, I like it.     http://www.inside3d.com/download.shtml


Notepad		Duh!				N/A (Comes with Win9x)

QmeLite		A mdl model editor. A demo      http://www.xs4all.nl/~renep/quakeme/
		version which only allows
		saving of models with 20
		or less frames.			

QuakeMe		The program that started        http://www.xs4all.nl/~renep/quakeme/
		Qme and Qmelite. From the
		same makers.

StudioMdx	This is a model editing 	http://www-kbs.ai.uiuc.edu/d-kruse/studioMDx/news.htm
		utility I found while 
		surfing the web. It's
		not finished and has some
		bugs but is cool, sorta.


PhotoShop 5.0   You should have heard of	http://www.adobe.com/ (the makers of PhotoShop) 
		this before. It's a 
		powerful graphics editing
		tool.			

NeoPaint	A pretty cool graphics		http://www.neosoftware.com/ (from the makers of
		editing tool. I use it 						quikmenu!)
		to do stuff in the
		Quake pallete. It's
		easy to use!


AdQuedit	A really good Quake		http://www.planetquake.com/chopshop/editing/quake/
		editing tool. Lets you           (Not adquedit based but they use it alot!)
		extract textures, sprites
		skins, pak files, etc.


Endoomer	An 'end screen' editing		http://www.planetquake.com/chopshop/editing/quake/
		tool. You know, the red
		screen that comes up when
		you exit Quake.	


Winpack		I used this to make the		N/A (you can get it from ftp.cdrom.com)
		pak file. It's a pak 
		editor.		


Meddle		This is the original		N/A for the original version. New version is lame.
		Dos version. I use it
		to convert ascii to mdl.	




-----------------
Technical Details
-----------------

Halo 9:

	All maps were constructed with Worldcraft 1.6. Textures were drawn 
from the following sources:

-Original Quake Texures
-Hexen II converted to Quake Palette (from Frib)
-Portal of Praveus converted to Quake Palette
-CTF Textures
-QRally Textures

Curves were made by 24-sided cylinders, hollowed out with the horizontal 
surfaces cut out. This makes for 8 angles between degrees of 0 and 90. 
Carving was used sparingly, and with much regret. Carving is evil. Do not 
carve.



Chazz:

 The car was modeled in Truespace SE 1.0, the first version of truespace. 
Then I exported it to an ascii file and converted it into an mdl with 
meddle. After that I used Neopaint v3.0 to draw a stupid texture.. Then I 
edited the model with StudioMDx and QmeLite. Also did some texture editing 
in QmeLite. 

 The code was written without outside help although I asked for it but never 
got it. If you look closely, the car doesn't angle itself to slopes yet. The
tilting is caused by the car turning. The top of the car tilts outward from 
the turn. Gives it a more realistic look. The car also slides a bit on the 
ground as to give the effect of uhh, sliding.. It doesn't slide much but it 
does allow for easy-to-do 180 turns and stuff. If you have questions then 
mail me (see below)..



Reporting bugs:

	Please look through the 'Known Bugs' section of this document above. If it's not in the list then
use common sense to figure out if it's map related or code releated.. Map related bugs goto Halo 9 and code related
go to Chazz.


------------------
Author Information
------------------

	'Lucid Designs' was started in December of '99. Although we didn't
have a name, we were still 'Lucid Designs'. It all started on the old 
I3d messageboard (www.inside3d.com). Chazz had given up entirely on Quake 
editing but hung out at the I3d messageboard to help budding programmers 
with their mods. Halo 9 told everyone about his quitting programming and 
just sticking with mapping. 

	He started to develop a mapping technique for making
Qrally maps. He dumped his last project 'Darkness-Awaits' for a qrally 
extension. He called it 'Qrally-Checkered Flag'. Chazz replied with a 
message saying he could do allthe coding and stuff since he had nothing 
better to do, only later did he find out that it'd be alot longer before 
the project would be finished. 


	Chazz worked his ass off on the physics to get them working.
Halo continued to explore the possibilities with his new segmented
tracking technique. Halo 9 later decided to change the name...
It was called 'Checkered Flag-GoldCup'. Chazz had a site up at
http://members.gotnet.net/chaz/ and had emailed planetquake about
the newest mod in development. 

	Within 30 minutes, PlanetQuake had
made the post on PQ and had offered to host the GoldCup site, this
was the beginning of something big. That same day, GoldCup was
all ready to go and was uploaded to PlanetQuake. The old site
now redirected people to the PlanetQuake site. It was cool....

	Soon enough, a beta demo came out. It wasn't a playable beta, 
just a demo to watch. People loved it. It was the first release of
GoldCup. In 2 weeks, Lucid Designs had accomplished 1/2 of an
equivalent to Qrally. Qrally took 8 months to get it to where it is
now. Nothing could stop us..................


	A few people offered to re-design the site for us.
Thomas 'Rebel Angel' Sturm was the lucky man who had made up a site
design at www.doomworld.com/deskdoom/gc/ (not there any longer).
we gave him the OK and he finished it off and sent us the zip..
We got the new site all uploaded and everything. We were getting 
bigger and better.....
 
	
	A few weeks later, another release was uhhhhhhhhhh, ummmnnn, 
released. But this one was playable. It included 3 car models and was 
very primitive. It came with all the code. It was the first playable 
beta of GoldCup. People sent in comments and stuff from all over the place. 
All of those comments helped make GoldCup's physics, graphics, maps and all
50% better. 

	Our goal is to always reach the finish line. Not with just speed
but with quality.	
	

We recommend you visit our website at: http://www.planetquake.com/goldcup/ and
check for news updates and version updates. We update almost everyday. There is
alot of info on there.


--------------------
Info On the Authors:
--------------------

	Joshua 'Halo 9' Klint
email=JKlint2569@aol.com

 Joshua is a pre-med student at California State University, Fresno. He is a 
junior, and maintains a 3.75 science GPA. He has applied to transfer to the 
University of California at Berkeley, Davis, and Santa Barbara for Fall of 
2000, and has already been accepted to UCSB. He has been mapping Quake for 
about a year now, and owes his geometric genius to the Legos he has 
collected over the course of his life. 


	Charlie 'Chazz' Van Noland
email=chazzmatazz@hotmail.com

 Started programming at age 7 in qbasic. Over time developed a knack for 3d
arts (clay, modeling) and 3d perceptual thinking.  Where he gets his 
ability to model crappy cars in 15 min. As he experimented with
Qbasic, he became a more logic thinker. Spends time programming, loitering
on messageboards, hassling people, eating, etc. Spends 9/10 of spare time
in his life to computers.. Keeps 3.5 GPA in middle school (only 13!). Plans
on becoming a game developer/programmer later in life.



-------
Credits
-------
(These will be a demo in Quake soon)


-Game Concept and Designer-

	Joshua 'Halo 9' Klint

-Programming/Coding-

	Charlie 'Chazz' Van Noland
	(w/help from guys on I3d messageboard)

-Mapping-
	
	Joshua 'Halo 9' Klint

-Modeling and Skinning-

	Jeff 'Stecki' Garstecki
	Charlie 'Chazz' Van Noland

-Special Thanks to-

	Pappy-R: For getting us heard on PQ. (www.planetquake.com)
	Terry 'Akuma' Goodwin: For support and being cool..
	Thomas 'Rebel Angel' Sturm: The tight webpage design..

	Ryan 'Ridha' Feltrin: For letting us do this and helping us
			      outtuv the tight spots. Mainly showing us
			      the light....... (he's the programmer for
			      The Impact Team!)


--------------------------------------
Copyright and Distribution Permissions
--------------------------------------
 
 Do what you want EXCEPT redistributing the zip after it's contents have been
modified at all. Just make sure that if you distribute it, you distribute 
the original copy from the GoldCup site and not one you edited and stuff. 

Alright, be that way. Wanna know what I am 
going to do because of that? Watch....

THE CONTENT AND DESIGN OF BOTH THE MOD 'Checkered Flag-GoldCup' AND
THE GoldCup WEBPAGE (www.planetquake.com/goldcup/) ARE COPYRIGHTED
BY Team Impact AND Lucid Designs. ALL RIGHTS RESERVED.

 There, now you can't steal our logos and stuff. Well you are capable of it
but it's supposed to be against the constitution or something like that. Oh
last but not least, have fun.. :?)

(Readme written by Charlie 'Chazz' Van Noland)