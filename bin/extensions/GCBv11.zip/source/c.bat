cd..
cd..
quake -game racer +map map1

