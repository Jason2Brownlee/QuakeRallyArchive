Title    : OZ rims for QuakeRally 1.2
Filename : fwhl_oz.zip
Version  : 1.01
Date     : 12.13.97
Author   : jeff M. garstecki - "stecki"
Email    : jeff_garstecki@playstation.sony.com
Thanks   : Id software, Ridah, Sumaleth,
	   

Type of Mod
-----------
Quake C  : no
Sound    : no
MDL      : yes  


Description of the Modification
-------------------------------

this little baby sticks OZ monte carlo five spoke rims onto the QuakeRally cars.

How to Install the OZ rims
-------------------------
basically unzip this mdl into your models directory (that's quake/rally/models).  If you want to put it in the pak file, that's cool too.  Just remember to extract a copy in case you want to go back to the three spokes.  you must name this file "fwhl.mdl" or it won't work.

run quakerally


Model Information
-----------------

Adobe Photoshop.  I get all my rims at:  http://www.tirerack.com  they have great end on shots of rims perfect for this kinda stuff...


Bugs
----

none that i know of.  i don't know how it looks and can't vouche for GL versions, cause I don't have that.  let me know if somethings wrong though...


Copyright and Distribution Permissions
--------------------------------------

do with it what you will.  I'd appreciate it if you kept the file at my place and link to the page.  I need a counter hit to know if i should keep on spending my time doing this.  barely anybody e-mails me with a comment, so the counter hits is all i got (sniff sniff).


contact info:

jeff M. garstecki - W:jeff_garstecki@playstation.sony.com
		    H:stecki19@idt.net
		  web:http://ally.ios.com/~stecki19

visit impact's homepage for the latest quakerally info at:
http://impact.frag.com


